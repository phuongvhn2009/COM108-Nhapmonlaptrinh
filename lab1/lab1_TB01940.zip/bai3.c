#include <stdio.h>
int main(){
    printf("Ho va ten: Vu Hoang Nhat Phuong\nLop: SD2001\nMSSV: TB01940\n");
    return 0;
}
