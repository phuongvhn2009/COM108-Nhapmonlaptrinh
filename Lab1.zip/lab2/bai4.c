#include  <stdio.h>
 int main(){
    float a, b, c;
    printf("nhap diem 3 mon toan ly hoa:");
    scanf("%f%f%f",&a,&b,&c);
    printf("diem trung binh la: %.2f",(a*3+b*2+c)/6);
    return 0;
 }




