#include <stdio.h>
 int main(){
    printf("nhap 2 so: ");
    int a, b;
    scanf("%d%d", &a, &b);
    printf("tong la: %d\n", a + b);
    printf("hieu la: %d\n",a-b);
    return 0;
 }
