#include <stdio.h>
 int main(){
    printf("nhap chieu dai va chieu rong: ");
    int a, b;
    scanf("%d%d", &a, &b);
    printf("chu vi la: %d\n",(a*2+b*2));
    printf("dien tich la: %d\n", a * b);
    return 0;
 }
