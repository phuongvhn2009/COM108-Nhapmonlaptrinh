#include <stdio.h>
#include <stdlib.h>
int main(){

    int cn;

    do {
		system("cls");
        int n,min,max,i,dem=0;
        float d=0,tb;
        int dd=0;

		printf("------ --------Bang menu------ --------\n");
        printf("| Chuc nang 1: tinh trung binh cong   |\n");
        printf("| Chuc nang 2: tim so nguyen to    |\n");
        printf("| Chuc nang 3: tim so chinh phuong       |\n");
        printf("| Chuc nang 4: thoat                  |\n");
        printf(" --------------------------------------\n");
        printf("          Nhap chuc nang: ");
        scanf("%d", &cn);
        switch (cn)
        {
        case 1:
            printf("Nhap gia tri min, max: ");
            scanf("%d%d",&min,&max);
            i=min;
            while (i<=max) {
                if (i % 2==0) {
                    dem++;
                    d=d+i;
                }
                i++;
            }
            
            tb = d/dem;
        
            
            printf("trung binh tong la: %f\n\n\n",tb);
            getch();
            break;
        case 2:
            
            scanf("%d",&n);
            i=2;
            
            for (i = 2; i <= n/2; i++) {
        		if (n % i == 0) {
            	d = 1; 
            	break;
        		}
    		}
            
            if (n<0){
                printf("ko phai la so nguyen to\n\n");
                getch();
            }
            else if (dd==0){
                printf("%d la so nguyen to\n\n",n);
                getch();
            }
            else if (dd!=0) {
                printf("%d khong phai so nguyen to\n\n",n);
                getch();
            }
            break;
        case 3:
            scanf("%d",&n);
            for (i=1;i<n;i++){
                if(i*i==n){
                    printf("So chinh phuong\n\n");
                    break;
                }
            }
            printf("Khong phai so chinh phuong\n\n");
            getch();
            break;
        case 4:
        	return 0;
        
        }
    } while (cn!=4);
    return 0;
}
